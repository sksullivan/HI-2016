//
//  AppDelegate.swift
//  IR-Remote
//
//  Created by them on 2/19/16.
//  Copyright © 2016 them. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var socket: SocketIOClient!
    var window: UIWindow?
    var pingCount = 0
    var deviceOn = false
    
    weak var actionLabel: UILabel!
    weak var statusRect: UIImageView!
    weak var statusLabel: UILabel!
    
    var currentButtonCode = ""
    
    weak var vc: FirstViewController!
    
    var remoteName: String!

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        socket = SocketIOClient(socketURL: NSURL(string: "http://192.168.43.201:8080")!)
        //socket = SocketIOClient(socketURL: NSURL(string: "http://localhost:8080")!)
        
        socket.on("connect") {data, ack in
            print("Connected.")
        }
        
        socket.on("availableRemotes") {data, ack in
            print(data)
            self.remoteName = (data.first as! NSDictionary).keyEnumerator().nextObject() as! String
        }
        
        socket.connect()
        
        return true
    }

    func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }

    func swipe(sender: UISwipeGestureRecognizer) {
        print("swiped some shit \(sender.direction)")
        actionLabel.alpha = 0
        actionLabel.text = "Swipe"
        UIView.animateWithDuration(0.2) { () -> Void in
            self.actionLabel.alpha = 1
        }
        if (sender.direction == UISwipeGestureRecognizerDirection.Up) {
            socket.emit("startButtonPress", ["remote":remoteName,"code":"KEY_CHANNELUP"])
            currentButtonCode = "KEY_CHANNELUP"
        } else if (sender.direction == UISwipeGestureRecognizerDirection.Down) {
            socket.emit("startButtonPress", ["remote":remoteName,"code":"KEY_CHANNELDOWN"])
            currentButtonCode = "KEY_CHANNELDOWN"
        } else if (sender.direction == UISwipeGestureRecognizerDirection.Left) {
            socket.emit("startButtonPress", ["remote":remoteName,"code":"KEY_VOLUMEDOWN"])
            currentButtonCode = "KEY_VOLUMEDOWN"
        } else {
            socket.emit("startButtonPress", ["remote":remoteName,"code":"KEY_VOLUMEUP"])
            currentButtonCode = "KEY_VOLUMEUP"
        }
    }
    
    func pan(sender: UIPanGestureRecognizer) {
        if (sender.state == UIGestureRecognizerState.Ended) {
            socket.emit("stopButtonPress", ["remote":remoteName,"code":currentButtonCode])
            print("Stop")
        }
    }

    func long(sender: UISwipeGestureRecognizer) {
        print("long pressed some shit \(sender.locationOfTouch(0, inView: sender.view))")
        if (sender.state == UIGestureRecognizerState.Began) {
            socket.emit("singleButtonPress", ["remote":remoteName,"code":"KEY_POWER"])
            actionLabel.alpha = 0
            actionLabel.text = "Long Tap"
            UIView.animateWithDuration(0.2) { () -> Void in
                self.actionLabel.alpha = 1
                if (!self.deviceOn) {
                    self.statusRect.backgroundColor = UIColor(red: 130/255.0, green: 210/255.0, blue: 109/255.0, alpha: 1)
                    self.statusLabel.text = "Device On"
                } else {
                    self.statusRect.backgroundColor = UIColor(red: 210/255.0, green: 109/255.0, blue: 109/255.0, alpha: 1)
                    self.statusLabel.text = "Device Off"
                }
                self.deviceOn = !self.deviceOn
            }
        }
    }
    
    func tap(sender: UISwipeGestureRecognizer) {
        print("tapped some shit \(sender.locationOfTouch(0, inView: sender.view))")
        actionLabel.alpha = 0
        actionLabel.text = "Tap"
        UIView.animateWithDuration(0.2) { () -> Void in
            self.actionLabel.alpha = 1
        }
        vc.toggleKeypad()
        vc.toggleOthers()
    }
    
    func keypad(sender: UITapGestureRecognizer) {
        print("\(sender.view!.tag) pressed.")
        sender.view!.alpha = 0
        UIView.animateWithDuration(0.2) { () -> Void in
            sender.view!.alpha = 1
        }
        if (sender.view!.tag == -2) {
            vc.toggleKeypad()
            vc.toggleOthers()
        } else if (sender.view!.tag == -1) {
            socket.emit("singleButtonPress", ["remote":remoteName,"code":"KEY_102ND"])
        } else {
            socket.emit("singleButtonPress", ["remote":remoteName,"code":"KEY_\(sender.view!.tag)"])
        }
    }
    
    func turnOff() {
        if (!deviceOn) {
            print("It's already off.")
            return
        }
        print("Turning off.")
        socket.emit("singleButtonPress", ["remote":remoteName,"code":"KEY_POWER"])
        actionLabel.alpha = 0
        actionLabel.text = "Timer"
        UIView.animateWithDuration(0.2) { () -> Void in
            self.statusRect.backgroundColor = UIColor(red: 210/255.0, green: 109/255.0, blue: 109/255.0, alpha: 1)
            self.statusLabel.text = "Device Off"
            self.deviceOn = false
        }
    }
}

