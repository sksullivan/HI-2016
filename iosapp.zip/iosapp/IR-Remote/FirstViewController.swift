//
//  FirstViewController.swift
//  IR-Remote
//
//  Created by them on 2/19/16.
//  Copyright © 2016 them. All rights reserved.
//

import UIKit


class FirstViewController: UIViewController, UIGestureRecognizerDelegate {

    var downSwipeGestureRecognizer: UISwipeGestureRecognizer!
    var upSwipeGestureRecognizer: UISwipeGestureRecognizer!
    var leftSwipeGestureRecognizer: UISwipeGestureRecognizer!
    var rightSwipeGestureRecognizer: UISwipeGestureRecognizer!
    var longGestureRecognizer: UILongPressGestureRecognizer!
    var tapGestureRecognizer: UITapGestureRecognizer!
    var panGestureRecognizer: UIPanGestureRecognizer!
    
    var del = UIApplication.sharedApplication().delegate as! AppDelegate
    
    @IBOutlet weak var actionLabel: UILabel!
    @IBOutlet weak var statusRect: UIImageView!
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var button1: UIImageView!
    @IBOutlet weak var button2: UIImageView!
    @IBOutlet weak var button3: UIImageView!
    @IBOutlet weak var button4: UIImageView!
    @IBOutlet weak var button5: UIImageView!
    @IBOutlet weak var button6: UIImageView!
    @IBOutlet weak var button7: UIImageView!
    @IBOutlet weak var button8: UIImageView!
    @IBOutlet weak var button9: UIImageView!
    @IBOutlet weak var button0: UIImageView!
    @IBOutlet weak var buttonDash: UIImageView!
    @IBOutlet weak var buttonBack: UIImageView!
    @IBOutlet weak var chevBack: UIImageView!
    
    @IBOutlet weak var chPlusLabel: UILabel!
    @IBOutlet weak var chMinusLabel: UILabel!
    @IBOutlet weak var volPlusLabel: UILabel!
    @IBOutlet weak var volMinusLabel: UILabel!
    @IBOutlet weak var longLabel: UILabel!
    @IBOutlet weak var tapLabel: UILabel!
    
    @IBOutlet weak var rightChev: UIImageView!
    @IBOutlet weak var leftChev: UIImageView!
    @IBOutlet weak var upChev: UIImageView!
    @IBOutlet weak var downChev: UIImageView!
    
    @IBOutlet weak var moveToTimer: UILabel!
    
    var keypadButtons = [UIImageView!]()
    var labels = [UILabel!]()
    var otherStuff = [UIImageView!]()
    var gestureRecognizers = [UIGestureRecognizer!]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        button1.tag = 1
        button2.tag = 2
        button3.tag = 3
        button4.tag = 4
        button5.tag = 5
        button6.tag = 6
        button7.tag = 7
        button8.tag = 8
        button9.tag = 9
        button0.tag = 0
        buttonDash.tag = -1
        buttonBack.tag = -2
        
        keypadButtons.append(button1)
        keypadButtons.append(button2)
        keypadButtons.append(button3)
        keypadButtons.append(button4)
        keypadButtons.append(button5)
        keypadButtons.append(button6)
        keypadButtons.append(button7)
        keypadButtons.append(button8)
        keypadButtons.append(button9)
        keypadButtons.append(button0)
        keypadButtons.append(buttonDash)
        keypadButtons.append(buttonBack)
        keypadButtons.append(chevBack)
        
        labels.append(chPlusLabel)
        labels.append(chMinusLabel)
        labels.append(volPlusLabel)
        labels.append(volMinusLabel)
        labels.append(longLabel)
        labels.append(tapLabel)
        
        otherStuff.append(rightChev)
        otherStuff.append(leftChev)
        otherStuff.append(upChev)
        otherStuff.append(downChev)
        
        downSwipeGestureRecognizer = UISwipeGestureRecognizer(target: del, action: "swipe:")
        downSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirection.Down
        view.addGestureRecognizer(downSwipeGestureRecognizer)
        upSwipeGestureRecognizer = UISwipeGestureRecognizer(target: del, action: "swipe:")
        upSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirection.Up
        view.addGestureRecognizer(upSwipeGestureRecognizer)
        rightSwipeGestureRecognizer = UISwipeGestureRecognizer(target: del, action: "swipe:")
        rightSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirection.Right
        view.addGestureRecognizer(rightSwipeGestureRecognizer)
        leftSwipeGestureRecognizer = UISwipeGestureRecognizer(target: del, action: "swipe:")
        leftSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirection.Left
        view.addGestureRecognizer(leftSwipeGestureRecognizer)
        
        longGestureRecognizer = UILongPressGestureRecognizer(target: del, action: "long:")
        view.addGestureRecognizer(longGestureRecognizer)
        tapGestureRecognizer = UITapGestureRecognizer(target: del, action: "tap:")
        view.addGestureRecognizer(tapGestureRecognizer)
        panGestureRecognizer = UIPanGestureRecognizer(target: del, action: "pan:")
        view.addGestureRecognizer(panGestureRecognizer)
        
//        let tapRG = UITapGestureRecognizer(target: self, action: "moveToTimer:")
//        moveToTimer.addGestureRecognizer(tapRG)
        
        panGestureRecognizer.delegate = self
        downSwipeGestureRecognizer.delegate = self
        leftSwipeGestureRecognizer.delegate = self
        rightSwipeGestureRecognizer.delegate = self
        upSwipeGestureRecognizer.delegate = self
        
        gestureRecognizers.append(downSwipeGestureRecognizer)
        gestureRecognizers.append(upSwipeGestureRecognizer)
        gestureRecognizers.append(leftSwipeGestureRecognizer)
        gestureRecognizers.append(rightSwipeGestureRecognizer)
        gestureRecognizers.append(longGestureRecognizer)
        gestureRecognizers.append(tapGestureRecognizer)
        gestureRecognizers.append(panGestureRecognizer)
        
        del.vc = self
        del.actionLabel = actionLabel
        del.statusLabel = statusLabel
        del.statusRect = statusRect
        setupKeypad()
        toggleKeypad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setupKeypad() {
        for button: UIImageView! in keypadButtons {
            let tapRecognizer = UITapGestureRecognizer(target: del, action: "keypad:")
            button.userInteractionEnabled = true
            button.addGestureRecognizer(tapRecognizer)
        }
    }

    func toggleKeypad() {
        for button: UIImageView! in keypadButtons {
            button.hidden = !button.hidden
        }
    }
    
    func toggleOthers() {
        for label: UILabel! in labels {
            label.hidden = !label.hidden
        }
        for chev: UIImageView! in otherStuff {
            chev.hidden = !chev.hidden
        }
        for recognizer: UIGestureRecognizer! in gestureRecognizers {
            recognizer.enabled = !recognizer.enabled
        }
    }
    
    func moveToTimer(sender: UITapGestureRecognizer!) {
        performSegueWithIdentifier("moveToTimer", sender: self)
    }
    
    func gestureRecognizer(gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWithGestureRecognizer otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
    
    func gestureRecognizer(gestureRecognizer: UIGestureRecognizer, shouldReceiveTouch touch: UITouch) -> Bool {
        return true
    }
    
    func gestureRecognizerShouldBegin(gestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }

}

