//
//  FirstViewController.swift
//  IR-Remote
//
//  Created by them on 2/19/16.
//  Copyright © 2016 them. All rights reserved.
//

import UIKit


class TimerViewController: UIViewController {
    
    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var set: UIImageView!
    @IBOutlet weak var setLabel: UILabel!
    @IBOutlet weak var picker: UIDatePicker!
    
    var del = UIApplication.sharedApplication().delegate as! AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backTGR = UITapGestureRecognizer(target: self, action: "move:")
        back.addGestureRecognizer(backTGR)
        back.userInteractionEnabled = true
        back.tag = 1
        
        let setTGR = UITapGestureRecognizer(target: self, action: "move:")
        set.addGestureRecognizer(setTGR)
        set.userInteractionEnabled = true
        set.tag = 0
        setLabel.text = "SET"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func move(sender: UITapGestureRecognizer!) {
        if (sender.view!.tag == 0) {
            if (setLabel.text == "SET") {
                del.socket.emit("startSleepTimer", ["remote":del.remoteName,"duration":picker.countDownDuration])
                setLabel.text = "X"
                performSegueWithIdentifier("backToMain", sender: self)
            } else {
                del.socket.emit("cancelSleepTimer", ["remote":del.remoteName])
                setLabel.text = "SET"
            }
        } else {
            performSegueWithIdentifier("backToMain", sender: self)
        }
    }
}

